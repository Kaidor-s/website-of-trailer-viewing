<a href="<?=$default_href_A?>" class="authorization">
	<p>Вход&nbsp;для&nbsp;администрации</p>
</a>
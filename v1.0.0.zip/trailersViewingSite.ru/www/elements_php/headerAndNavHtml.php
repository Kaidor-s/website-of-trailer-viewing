<div id="header">
	<p>Кинотеатр&nbsp;"КинотеатрЪ"</p>	
</div>
<div id="menu">
	<a href="<?=$href_main?>" class="hrefElem"><strong>Главная</strong></a>
	<a href="<?=$href_catalog?>" class="hrefElem"><strong>Премьеры&nbsp;фильмов</strong></a>
	<a href="" class="hrefElem"><strong>О&nbsp;нас</strong></a>
	<a href="" class="hrefElem"><strong>Связаться&nbsp;с&nbsp;нами</strong></a>
</div>
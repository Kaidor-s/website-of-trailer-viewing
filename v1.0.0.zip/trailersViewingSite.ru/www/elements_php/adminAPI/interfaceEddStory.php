<?php
	echo "<input type='submit' id='done_eDF_id' value='Изменить сюжет' name='done_eDF'/>";
	//echo "<button id='done_eDF_id' name='done_eDF'>Изменить сюжет</button>";
	echo "<form action='".$defaultAdress_EDFButt."' enctype='multipart/form-data' method='post' id='form_buttEDF'></form>";
	//echo "<div id='form_buttEDF'></div>";
	echo "<script src='".$defaultAdress_jsInterface."'></script>";
?>





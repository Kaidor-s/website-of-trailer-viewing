<form action="../php/adminAPI/exitAdminAPI.php" method="post">
	<input type="submit" class="authorization" value="Выйти&nbsp;с&nbsp;админки" name="done">
</form>


